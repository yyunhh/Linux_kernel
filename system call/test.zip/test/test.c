#include <stdio.h>
#include <linux/kernel.h>
#include <sys/syscall.h>
#include <unistd.h>
#define __NR_mycall 307
#include <string.h>
#include <stdlib.h>

int main() 
{
    char str[10] = "123456789101112131415161718";
    long int ret = syscall(__NR_mycall, str);
    printf("return: %ld\n", ret);
    
    return 0;
}
